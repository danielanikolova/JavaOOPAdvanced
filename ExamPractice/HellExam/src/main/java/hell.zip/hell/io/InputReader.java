package hell.io;

public interface InputReader {
    String readLine();
}
