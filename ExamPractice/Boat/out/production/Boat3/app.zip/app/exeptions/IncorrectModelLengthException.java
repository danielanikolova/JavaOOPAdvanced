package app.exeptions;

public class IncorrectModelLengthException extends Throwable {
    public IncorrectModelLengthException(String message) {
        super(message);
    }
}
