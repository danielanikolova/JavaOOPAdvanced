package app.exeptions;

public class IncorrectPropertyValueException extends Throwable {
    public IncorrectPropertyValueException(String message) {
        super(message);
    }
}
