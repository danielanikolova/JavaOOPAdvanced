package app.contracts;

public interface Modelable {
    String getModel();
}
